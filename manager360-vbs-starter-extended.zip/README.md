# Manager 360 – Visual Builder (VBS) App (Extended)

This package extends the starter with:
- **Pre-wired Action Chains** (template bindings) for KPIs, Directs, Absences, Goals, Learning, and Approvals
- **Mass Actions** panel: CSV upload → validate/preview → generate REST PATCH payload → submit
- **Service stubs** for HCM and BPM (approvals)
- Redwood layout + nav

> Import into **Visual Builder** and point the Services to your pod. Replace the `baseUrl` and auth in service connections.
> All action chains are **template-wired** and reference the service names `HCM` and `BPM` so they attach automatically if the
> service connection names match.

## Service Connections
- **HCM**: `https://<your-host>/hcmRestApi/resources/latest/`
- **BPM**: `https://<your-host>/bpm/api/4.0/`  (list tasks) OR your Fusion REST family endpoint for human tasks

## Key Action Chains
- `loadManagerInfo` → resolves current user, manager personId (replace with your SSO or a user profile endpoint).
- `loadDirects` → GET `HCM/workers?onlyData=true&managerId={managerPersonId}` → sets `directs`, `kpis.headcount`.
- `loadKPIs` → aggregates pending approvals (BPM), learning due count, and open req (placeholder).
- `loadAbsencesForTeam` → loops directs → GET `HCM/absences?personNumber=...` → flattens to `absencesFlat`.
- `loadTalent` → GET goals, performance docs, learning for each direct (or current person).
- `loadApprovals` → GET `BPM/tasks?assignee={username}&state=ASSIGNED` → sets `tasks`.
- `approve`, `reject`, `requestInfo` → POST/PUT to BPM task endpoints (placeholders included).

## Mass Actions
- CSV Template columns: `PersonNumber,Field,NewValue,EffectiveStartDate,Reason`
- Validates rows, groups by Field, previews changes, and builds **PATCH** payloads for `/workers/{workerId}/child/assignments` or relevant endpoint.
- Submit with confirmation dialog. You will map `Field` to an allowed set and endpoint per your policy.

## Setup
1. Create Service Connections named exactly **HCM** and **BPM**.
2. Import or copy the **pages**, **flows**, and **actionChains** into your `manager360` app.
3. Open each Action Chain; verify endpoint mapping and auth for your pod.
4. Publish and add as **Page Integration** in HCM for managers.

### Security
Grant the integration role **view direct reports** and specific object privileges (Absences, Goals, Learning, Performance, BPM Tasks). Use server-side connections in production.
