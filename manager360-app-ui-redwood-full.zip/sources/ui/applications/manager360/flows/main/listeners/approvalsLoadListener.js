
import { ApplicationChain } from "@oracle/oraclejet-app/chain";
import ArrayDataProvider from "ojs/ojarraydataprovider";

export class ApprovalsLoadListener extends ApplicationChain {
    async execute() {
        try {
            const response = await this.services.BPM.get("tasks");
            this.page.variables.approvalsData.dataProvider = new ArrayDataProvider(response.items, { keyAttributes: "id" });
        } catch (err) {
            this.page.variables.approvalsData.dataProvider = new ArrayDataProvider([{'id': 'MCK-001', 'name': 'Approve Leave Request', 'status': 'PENDING'}, {'id': 'MCK-002', 'name': 'Approve Job Change', 'status': 'PENDING'}], { keyAttributes: "id" });
        }
    }
}
