
import { ApplicationChain } from "@oracle/oraclejet-app/chain";
import ArrayDataProvider from "ojs/ojarraydataprovider";

export class TalentLoadListener extends ApplicationChain {
    async execute() {
        try {
            const response = await this.services.HCM.get("workers");
            this.page.variables.talentData.dataProvider = new ArrayDataProvider(response.items, { keyAttributes: "id" });
        } catch (err) {
            this.page.variables.talentData.dataProvider = new ArrayDataProvider([{'id': 'TAL-001', 'name': 'High Potential - John Doe', 'status': 'ACTIVE'}], { keyAttributes: "id" });
        }
    }
}
