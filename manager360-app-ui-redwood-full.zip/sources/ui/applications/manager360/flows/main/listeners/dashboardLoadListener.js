
import { ApplicationChain } from "@oracle/oraclejet-app/chain";
import ArrayDataProvider from "ojs/ojarraydataprovider";

export class DashboardLoadListener extends ApplicationChain {
    async execute() {
        try {
            const response = await this.services.HCM.get("workers");
            this.page.variables.dashboardData.dataProvider = new ArrayDataProvider(response.items, { keyAttributes: "id" });
        } catch (err) {
            this.page.variables.dashboardData.dataProvider = new ArrayDataProvider([{'id': '1', 'name': 'Team Size: 12', 'status': 'OK'}, {'id': '2', 'name': 'Pending Approvals', 'status': '5'}], { keyAttributes: "id" });
        }
    }
}
