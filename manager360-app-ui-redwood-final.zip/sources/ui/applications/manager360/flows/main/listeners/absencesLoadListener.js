
import { ApplicationChain } from "@oracle/oraclejet-app/chain";
import ArrayDataProvider from "ojs/ojarraydataprovider";

export class AbsencesLoadListener extends ApplicationChain {
    async execute() {
        try {
            const response = await this.services.HCM.get("workers");
            this.page.variables.absencesData.dataProvider = new ArrayDataProvider(response.items, { keyAttributes: "id" });
        } catch (err) {
            this.page.variables.absencesData.dataProvider = new ArrayDataProvider([{'id': 'ABS-001', 'name': 'Annual Leave', 'status': 'APPROVED'}], { keyAttributes: "id" });
        }
    }
}
