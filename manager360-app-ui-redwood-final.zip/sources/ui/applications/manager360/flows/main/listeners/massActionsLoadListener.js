
import { ApplicationChain } from "@oracle/oraclejet-app/chain";
import ArrayDataProvider from "ojs/ojarraydataprovider";

export class MassactionsLoadListener extends ApplicationChain {
    async execute() {
        try {
            const response = await this.services.HCM.get("workers");
            this.page.variables.massActionsData.dataProvider = new ArrayDataProvider(response.items, { keyAttributes: "id" });
        } catch (err) {
            this.page.variables.massActionsData.dataProvider = new ArrayDataProvider([{'id': 'ACT-001', 'name': 'Mass Manager Update', 'status': 'PENDING'}], { keyAttributes: "id" });
        }
    }
}
